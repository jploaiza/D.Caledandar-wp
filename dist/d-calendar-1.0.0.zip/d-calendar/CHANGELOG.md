# Changelog

Todos los cambios notables de este proyecto serán documentados aquí.

## [1.0.0] - 2026-01-28

### Añadido
- Sincronización con Google Calendar
- Integración Zoom Meetings
- Notificaciones WhatsApp
- Sistema de seguridad con tokens
- Panel de administración completo

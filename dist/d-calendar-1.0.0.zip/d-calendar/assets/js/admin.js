(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 */
	$(document).ready(function() {
		// Admin JS
	});

})( jQuery );

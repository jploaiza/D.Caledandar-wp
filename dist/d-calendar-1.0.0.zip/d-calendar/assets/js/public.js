(function ($) {
    'use strict';

    /**
     * All of the code for your public-facing JavaScript source
     * should reside in this file.
     */
    $(document).ready(function () {
        // Public JS
    });

})(jQuery);
